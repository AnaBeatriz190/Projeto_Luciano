
package controlador;

import java.util.Random;

public class Sorte {
    private Random aleatorio = new Random();
    private int numeroSecreto;
    int dificuldade;
    public int criarNumeroFacil(){
        this.numeroSecreto = aleatorio.nextInt(10) + 1;
        this.dificuldade = 1;
        return this.numeroSecreto;
    }
    public int criarNumeroNormal(){
        this.numeroSecreto = aleatorio.nextInt(50) + 1;
        this.dificuldade = 2;
        return this.numeroSecreto;
    }
    public int criarNumeroDificil(){
        this.numeroSecreto = aleatorio.nextInt(100) + 1;
        this.dificuldade = 3;
        return this.numeroSecreto;
    }

    public int getNumeroSecreto() {
        return numeroSecreto;
    }

    public int getDificuldade() {
        return dificuldade;
    }
    
    
    
}
