
package com.mycompany.projetojogo_adivinha;


public class Advinha {

   
    public static void main(String[] args) {
       
    }
    
}
