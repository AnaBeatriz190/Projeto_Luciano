package com.mycompany.projetojogo_adivinha;
public class PROJETOJOGO_ADIVINHA {
    public static void main(String[] args) {
        JFHome home = new JFHome();
        home.setVisible(true);
    }
}
